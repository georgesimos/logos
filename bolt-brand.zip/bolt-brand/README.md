# BOLT brand

Logo assets for **BOLT**: workspaces of blotters and charts, with actions and links between tabs, plus a monorepo for team apps on the internal cloud.

## Concept
Three panes (one tall, two stacked) are a BOLT workspace layout. An amber bolt cuts through them: speed, and the actions and relationships between views.

## Chosen direction: "3b"
Tinted layout, navy bolt, lowercase `bolt` wordmark.

## Files
| Path | Use |
|---|---|
| `logo/lockup-horizontal.svg` | Primary logo, light backgrounds |
| `logo/lockup-stacked.svg` | Square spaces: login, splash |
| `logo/lockup-dark.svg` | Dark backgrounds |
| `logo/mark.svg` | Mark only, 24 px and up |
| `logo/mark-solid.svg` | Mark only, below 24 px |
| `logo/mark-dark.svg` | Mark only, dark backgrounds |
| `logo/app-icon.svg` | App / launcher icon |
| `logo/favicon.svg` | Favicon (SVG), one color, switches navy/white with the OS theme |
| `logo/mono/` | One-color set: mark, solid mark, horizontal and stacked lockups in navy, black and white (transparent background, no halo), plus mono app icon and favicon |
| `logo/light/` | One-color navy on transparent, for **light** backgrounds (mark, solid mark, horizontal and stacked lockups) |
| `logo/dark/` | One-color white on transparent, for **dark** backgrounds (same four files) |
| `logo/adaptive/` | Same four files, switch navy/white automatically with the OS theme when used as `<img>` |
| `logo/favicon/` | Favicon set: adaptive `favicon.svg`, `favicon-tile.svg` (navy tile), `apple-touch-icon.svg`, `maskable-icon.svg` |
| `png/favicon/` | `favicon.ico` (16/32/48), `favicon-16/32/48.png`, `apple-touch-icon.png` (180), `icon-192/512.png`, `icon-maskable-192/512.png` |
| `banner/` | Store listing hero banner, 1920x640 (and @2x), dark and light. SVG text is outlined, so no font is needed. |
| `banner/store-banner-square-*`, `store-banner-4x3-*` | Squarer store banners: 1600x1600 (1:1) and 1600x1200 (4:3), dark and light, SVG + PNG + @2x |
| `banner/store-banner-1024x768-*` | 1024x768 PNG exports of the 4:3 banner, dark and light |
| `png/icon-256-*.png` | 256x256 store icon, rounded and full-bleed square (navy tile, one-color mark) |
| `png/` | Raster exports: app icon and favicon sizes, `favicon.ico` |
| `source/artboards/` | Every exploration and kit board (Design canvas source, `*.dc.html` + `canvas.json`) |

## Palette
| Name | Hex |
|---|---|
| Navy | `#0B1F3A` |
| Amber | `#FFB020` |
| Paper | `#F4F6FA` |
| Pane tint | Navy at 14% |

## Spec
- Clear space: x on every side, x = 1/4 of mark height.
- Minimum size: tinted mark 24 px. Below that use `mark-solid.svg` (16 px minimum).
- Wordmark: Archivo 700, lowercase, tracking +2%.

## Notes
- Tagline: "Every view, connected." Longer descriptor for store text: "Workspaces for blotters, charts and team apps."
- Wordmarks in all lockup SVGs are outlined (Archivo 700), so no font is needed.
- Not reviewed against JPM brand guidelines. Check palette and fonts before wider rollout.
- `source/artboards/` holds the 30+ exploration artboards (options A to D, minimal 1 to 7 and variants) and the 3b kit boards.

## Light and dark in HTML
```html
<!-- automatic, one file -->
<img src="logo/adaptive/lockup-horizontal.svg" alt="bolt" height="32">

<!-- or explicit -->
<picture>
  <source srcset="logo/dark/lockup-horizontal.svg" media="(prefers-color-scheme: dark)">
  <img src="logo/light/lockup-horizontal.svg" alt="bolt" height="32">
</picture>
```
If your app has its own theme toggle (not the OS setting), use the explicit `light/` and `dark/` files and switch on your theme state. The adaptive files only follow the OS.

## Favicon
```html
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="icon" href="/favicon.ico" sizes="32x32">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
```
`favicon.svg` is transparent and turns white in dark mode. `favicon.ico` and the PNGs use the navy tile so they stay visible on any browser chrome. In `manifest.webmanifest` list `icon-192.png`, `icon-512.png` and the `icon-maskable-*` files (with `"purpose": "maskable"`).
