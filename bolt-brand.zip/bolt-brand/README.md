# BOLT brand

Logo assets for **BOLT**: workspaces of blotters and charts, with actions and links between tabs, plus a monorepo for team apps on the internal cloud.

## Concept
Three panes (one tall, two stacked) are a BOLT workspace layout. An amber bolt cuts through them: speed, and the actions and relationships between views.

## Chosen direction: "3b"
Tinted layout, navy bolt, lowercase `bolt` wordmark.

## Files
| Path | Use |
|---|---|
| `logo/lockup-horizontal.svg` | Primary logo, light backgrounds |
| `logo/lockup-stacked.svg` | Square spaces: login, splash |
| `logo/lockup-dark.svg` | Dark backgrounds |
| `logo/mark.svg` | Mark only, 24 px and up |
| `logo/mark-solid.svg` | Mark only, below 24 px |
| `logo/mark-dark.svg` | Mark only, dark backgrounds |
| `logo/app-icon.svg` | App / launcher icon |
| `logo/favicon.svg` | Favicon (SVG) |
| `png/` | Raster exports: app icon and favicon sizes, `favicon.ico` |
| `source/artboards/` | Every exploration and kit board (Design canvas source, `*.dc.html` + `canvas.json`) |

## Palette
| Name | Hex |
|---|---|
| Navy | `#0B1F3A` |
| Amber | `#FFB020` |
| Paper | `#F4F6FA` |
| Pane tint | Navy at 14% |

## Spec
- Clear space: x on every side, x = 1/4 of mark height.
- Minimum size: tinted mark 24 px. Below that use `mark-solid.svg` (16 px minimum).
- Wordmark: Archivo 700, lowercase, tracking +2%.

## Notes
- Lockup SVGs use live `<text>` with Archivo, falling back to Helvetica Neue / Arial. Self-host Archivo or convert text to outlines before using them outside this repo.
- Not reviewed against JPM brand guidelines. Check palette and fonts before wider rollout.
- `source/artboards/` holds the 30+ exploration artboards (options A to D, minimal 1 to 7 and variants) and the 3b kit boards.
